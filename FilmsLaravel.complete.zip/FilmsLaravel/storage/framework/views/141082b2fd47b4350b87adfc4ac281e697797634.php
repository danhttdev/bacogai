<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 col-sm-12 mb-2">
            <div class="card" id='films-view'>
                
            </div>
            <hr>
            <div class="form-comment">
                <form action="" method="POST" id="form-comment-film">
                    <input type="text" name="comment-film" id='comment-film'>
                    <input type="submit" value="Comment">
                </form>
               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(URL::asset('js/films_view.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>