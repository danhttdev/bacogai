<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Create new film')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('api/films')); ?>" aria-label="<?php echo e(__('Create')); ?>" id="film-create-ajax" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Film name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <span class="text-danger" id="error-create-name"></span> 

                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-6">
                                <input id="description" type="text" class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" required>

                                <?php if($errors->has('description')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                               <?php endif; ?>
                                <span class="text-danger" id="error-create-description"></span> 

                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-4 col-form-label text-md-right"><?php echo e(__('Realease date')); ?></label>

                            <div class="col-md-6">
                                <input id="realease_date" type="date" class="form-control<?php echo e($errors->has('realease_date') ? ' is-invalid' : ''); ?>" name="realease_date" required>

                                <?php if($errors->has('realease_date')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('realease_date')); ?></strong>
                                    </span>
                               <?php endif; ?>
                                <span class="text-danger" id="error-create-realease_date"></span> 
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-4 col-form-label text-md-right"><?php echo e(__('Rating')); ?></label>

                            <div class="col-md-6">
                                <input id="rating" type="number" min="1" max="5" step="0.1" class="form-control<?php echo e($errors->has('rating') ? ' is-invalid' : ''); ?>" name="rating" required>

                                <?php if($errors->has('rating')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('rating')); ?></strong>
                                    </span>
                               <?php endif; ?>
                                <span class="text-danger" id="error-create-rating"></span> 
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ticket price')); ?></label>

                            <div class="col-md-6">
                                <input id="ticket_price" type="number" class="form-control<?php echo e($errors->has('ticket_price') ? ' is-invalid' : ''); ?>" min="0" max="1000" name="ticket_price" required>

                                <?php if($errors->has('ticket_price')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('ticket_price')); ?></strong>
                                    </span>
                               <?php endif; ?>
                                <span class="text-danger" id="error-create-ticket_price"></span> 
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-4 col-form-label text-md-right"><?php echo e(__('Country')); ?></label>

                            <div class="col-md-6">
                                <input id="country" type="text" class="form-control<?php echo e($errors->has('country') ? ' is-invalid' : ''); ?>" name="country" required>

                                <?php if($errors->has('country')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('country')); ?></strong>
                                    </span>
                               <?php endif; ?>
                                <span class="text-danger" id="error-create-country"></span> 
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-4 col-form-label text-md-right"><?php echo e(__('Genre')); ?></label>

                            <div class="col-md-6">
                                <div id="checkbox-genre">
                                    <input type="checkbox" name="genre[]" value="Action"> Action<br>
                                    <input type="checkbox" name="genre[]" value="Commedy"> Commedy<br>
                                    <input type="checkbox" name="genre[]" value="Fiction"> Fiction<br>
                                    <input type="checkbox" name="genre[]" value="Army"> Army<br>
                                </div>
                                
                                <?php if($errors->has('genre')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('genre')); ?></strong>
                                    </span>
                               <?php endif; ?>
                                <span class="text-danger" id="error-create-genre"></span> 
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-4 col-form-label text-md-right"><?php echo e(__('Photo')); ?></label>

                            <div class="col-md-6">
                                <input id="photo" type="file" class="form-control<?php echo e($errors->has('photo') ? ' is-invalid' : ''); ?>" name="photo" required>

                                <?php if($errors->has('photo')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('photo')); ?></strong>
                                    </span>
                               <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Create')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="<?php echo e(URL::asset('js/film_create.js')); ?>"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>